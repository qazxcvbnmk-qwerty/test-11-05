<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $stmt = $db->prepare("INSERT INTO users(username, password) VALUES(?, ?)");
    try {
        $stmt->execute([$username, $password]);
        echo "<script>alert('회원가입 성공!');location.href='login.php';</script>";
    } catch(Exception $e) {
        echo "<script>alert('이미 존재하는 아이디입니다');</script>";
    }
}
?>

<?php include "header.php"; ?>

<h3>회원가입</h3>
<form method="post">
    아이디: <input name="username"><br>
    비밀번호: <input type="password" name="password"><br>
    <button>가입하기</button>
</form>

<?php include "footer.php"; ?>
