<?php
include "config.php";

$rows = $db->query("SELECT b.*, u.username FROM board b 
JOIN users u ON b.user_id=u.id ORDER BY b.id DESC")->fetchAll();
?>

<?php include "header.php"; ?>

<h3>게시판</h3>
<a href="board_write.php">글쓰기</a>
<hr>

<?php foreach($rows as $r): ?>
    <div>
        <a href="board_view.php?id=<?= $r['id'] ?>">
            <b><?= $r["title"] ?></b>
        </a>
        <p>작성자: <?= $r["username"] ?></p>
    </div>
    <hr>
<?php endforeach; ?>

<?php include "footer.php"; ?>
