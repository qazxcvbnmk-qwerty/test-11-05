<?php include "config.php"; ?>
<?php include "header.php"; ?>

<h3>메인 페이지</h3>
<?php if (isLogin()): ?>
    <p>로그인됨: <?= $_SESSION["username"] ?></p>
<?php else: ?>
    <p>로그인 안됨</p>
<?php endif; ?>

<?php include "footer.php"; ?>
