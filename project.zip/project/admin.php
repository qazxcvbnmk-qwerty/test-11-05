<?php
include "config.php";

if (!isAdmin()) die("관리자만 접근 가능");
?>

<?php include "header.php"; ?>

<h3>관리자 페이지</h3>

<h4>유저 목록</h4>
<?php
$users = $db->query("SELECT * FROM users")->fetchAll();
foreach ($users as $u) {
    echo $u["id"]." | ".$u["username"]."<br>";
}
?>

<h4>피드백 내용</h4>
<pre><?php echo htmlspecialchars(@file_get_contents("feedback.txt")); ?></pre>

<h4>전자 서명</h4>
<pre><?php echo htmlspecialchars(@file_get_contents("signatures.txt")); ?></pre>

<?php include "footer.php"; ?>
