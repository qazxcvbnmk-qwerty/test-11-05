<?php
include "config.php";

if (!file_exists("feedback.txt")) file_put_contents("feedback.txt","");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $msg = htmlspecialchars($_POST["msg"]);
    file_put_contents("feedback.txt", $msg."\n", FILE_APPEND);
}
?>

<?php include "header.php"; ?>

<h3>익명 피드백</h3>
<form method="post">
    <textarea name="msg"></textarea><br>
    <button>전송</button>
</form>

<h4>누적 피드백</h4>
<pre><?php echo htmlspecialchars(file_get_contents("feedback.txt")); ?></pre>

<?php include "footer.php"; ?>
