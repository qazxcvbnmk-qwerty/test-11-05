<?php
include "config.php";

if (!isLogin()) die("로그인이 필요합니다.");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];

    $stmt = $db->prepare("INSERT INTO votes(title, yes_cnt, no_cnt) VALUES(?,0,0)");
    $stmt->execute([$title]);

    echo "<script>alert('투표 주제 생성 완료');location.href='vote.php';</script>";
}
?>

<?php include "header.php"; ?>

<h3>투표 주제 만들기</h3>
<form method="post">
    주제: <input name="title"><br>
    <button>생성</button>
</form>

<?php include "footer.php"; ?>
