<hr>
<footer>© Demo PHP Website</footer>
</body>
</html>
