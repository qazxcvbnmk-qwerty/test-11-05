<?php
include "config.php";

if (isset($_POST["vote"])) {
    $id = $_POST["id"];
    if ($_POST["vote"] == "yes") {
        $db->query("UPDATE votes SET yes_cnt=yes_cnt+1 WHERE id=$id");
    } else {
        $db->query("UPDATE votes SET no_cnt=no_cnt+1 WHERE id=$id");
    }
}

$rows = $db->query("SELECT * FROM votes ORDER BY id DESC")->fetchAll();
?>

<?php include "header.php"; ?>

<h3>투표 목록</h3>

<?php foreach($rows as $r): ?>
    <div>
        <b><?= $r["title"] ?></b><br>
        YES: <?= $r["yes_cnt"] ?> | NO: <?= $r["no_cnt"] ?><br>

        <form method="post">
            <input type="hidden" name="id" value="<?= $r["id"] ?>">
            <button name="vote" value="yes">YES</button>
            <button name="vote" value="no">NO</button>
        </form>
    </div>
    <hr>
<?php endforeach; ?>

<?php include "footer.php"; ?>
