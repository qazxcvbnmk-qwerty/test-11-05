<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stmt = $db->prepare("SELECT * FROM users WHERE username=?");
    $stmt->execute([$_POST["username"]]);
    $user = $stmt->fetch();

    if ($user && password_verify($_POST["password"], $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["is_admin"] = $user["is_admin"];
        header("Location: index.php");
        exit;
    } else {
        echo "<script>alert('로그인 실패');</script>";
    }
}
?>

<?php include "header.php"; ?>

<h3>로그인</h3>
<form method="post">
    아이디: <input name="username"><br>
    비밀번호: <input type="password" name="password"><br>
    <button>로그인</button>
</form>

<?php include "footer.php"; ?>
