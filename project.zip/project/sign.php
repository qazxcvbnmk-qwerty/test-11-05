<?php include "config.php"; ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    file_put_contents("signatures.txt", $name."\n", FILE_APPEND);
    echo "<script>alert('전자 서명 완료');location.href='index.php';</script>";
}
?>

<?php include "header.php"; ?>

<h3>전자 서명</h3>
<form method="post">
    이름: <input name="name"><br>
    <button>서명하기</button>
</form>

<?php include "footer.php"; ?>
