<?php
include "config.php";

if (!isLogin()) die("로그인 필요");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stmt = $db->prepare("INSERT INTO board(title, content, user_id) VALUES(?,?,?)");
    $stmt->execute([$_POST["title"], $_POST["content"], $_SESSION["user_id"]]);
    header("Location: board.php");
}
?>

<?php include "header.php"; ?>

<h3>글 작성</h3>
<form method="post">
    제목: <input name="title"><br>
    내용: <br><textarea name="content"></textarea><br>
    <button>저장</button>
</form>

<?php include "footer.php"; ?>


<?php include "footer.php"; ?>
