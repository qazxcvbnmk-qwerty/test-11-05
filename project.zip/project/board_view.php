<?php
include "config.php";

$id = $_GET["id"];
$stmt = $db->prepare("SELECT * FROM board WHERE id=?");
$stmt->execute([$id]);
$post = $stmt->fetch();
?>

<?php include "header.php"; ?>

<h3><?= $post["title"] ?></h3>
<p><?= nl2br(htmlspecialchars($post["content"])) ?></p>

<?php include "footer.php"; ?>
