<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP 사이트</title>
</head>
<body>
<header>
    <h2>PHP 데모 홈페이지</h2>
    <nav>
        <a href="index.php">메인</a> |
        <a href="signup.php">회원가입</a> |
        <a href="login.php">로그인</a> |
        <a href="logout.php">로그아웃</a> |
        <a href="feedback.php">익명 피드백</a> |
        <a href="vote_create.php">투표 생성</a> |
        <a href="vote.php">투표하기</a> |
        <a href="board.php">게시판</a> |
        <a href="sign.php">전자서명</a> |
        <a href="admin.php">관리자</a>
    </nav>
    <hr>
</header>
