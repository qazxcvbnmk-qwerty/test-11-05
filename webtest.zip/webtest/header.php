<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>My Secure Site</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/style.css">
</head>
<body>
<div class="container">
<header class="site-header">
  <div class="logo">My Secure Site</div>
  <nav class="nav">
    <?php if (!empty($_SESSION['username'])): ?>
      <a class="btn ghost" href="dashboard.php">대시보드</a>
      <a class="btn ghost" href="files.php">파일공유</a>
      <a class="btn" href="logout.php">로그아웃</a>
    <?php else: ?>
      <a class="btn" href="login_form.php">로그인</a>
      <a class="btn ghost" href="register_form.php">회원가입</a>
    <?php endif; ?>
  </nav>
</header>
<hr>
<main>
