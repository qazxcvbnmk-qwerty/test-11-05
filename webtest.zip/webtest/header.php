<?php
require_once __DIR__ . '/config.php';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="/style.css">
<title>My App</title>
</head>
<body>
<div class="container">
<header>
  <div class="logo">My Secure Site</div>
  <div class="nav">
    <?php if (isset($_SESSION['username'])): ?>
      <a class="btn ghost" href="dashboard.php">대시보드</a>
      <a class="btn ghost" href="logout.php">로그아웃</a>
    <?php else: ?>
      <a class="btn" href="login_form.php">로그인</a>
    <?php endif; ?>
  </div>
</header>
<hr>
footer.php
<hr>
<footer class="small">© Your Site</footer>
</div>
</body>
</html>