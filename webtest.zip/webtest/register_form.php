<?php require_once 'header.php'; ?>
<h1>회원가입</h1>
<form action="register.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">
    <label>아이디:</label><br>
    <input class="input" type="text" name="username" required><br>
    <label>이메일:</label><br>
    <input class="input" type="email" name="email" required><br>
    <label>비밀번호:</label><br>
    <input class="input" type="password" name="password" required><br>
    <label>프로필 이미지:</label><br>
    <input type="file" name="profile_image" accept="image/*"><br><br>
    <button class="btn" type="submit">가입하기</button>
</form>
<?php require_once 'footer.php'; ?>