<?php require_once 'header.php'; ?>

<h1>회원가입</h1>

<form action="register.php" method="POST" enctype="multipart/form-data" class="form">
    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">

    <label>아이디</label>
    <input class="input" type="text" name="username" required>

    <label>이메일</label>
    <input class="input" type="email" name="email" required>

    <label>비밀번호 (6자 이상)</label>
    <input class="input" type="password" name="password" required>

    <label>프로필 이미지 (선택)</label>
    <input type="file" name="profile_image" accept="image/*">

    <button class="btn" type="submit">가입하기</button>
</form>

<p><a href="login_form.php">이미 계정이 있으신가요? 로그인</a></p>

<?php require_once 'footer.php'; ?>
