<?php
require_once 'config.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$key = $_GET['file'] ?? '';

if ($key === '' || strpos($key, "uploads/{$uid}/") !== 0) {
    die('잘못된 파일 요청');
}

try {
    $cmd = $s3->getCommand('GetObject', ['Bucket' => $S3_BUCKET, 'Key' => $key]);
    $request = $s3->createPresignedRequest($cmd, '+5 minutes');
    $url = (string)$request->getUri();
    header('Location: ' . $url);
    exit;
} catch (Exception $e) {
    error_log('S3 presign error: '.$e->getMessage());
    die('다운로드 실패');
}