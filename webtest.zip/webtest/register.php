<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit('잘못된 접근');
if (!csrf_check($_POST['csrf_token'] ?? '')) die('CSRF 검증 실패');

$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $email === '' || $password === '') {
    die('모든 필드를 입력하세요.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) die('유효한 이메일 필요');
if (strlen($password) < 6) die('비밀번호는 최소 6자 이상');

// 중복 확인
$stmt = $conn->prepare("SELECT id FROM members WHERE username=? OR email=? LIMIT 1");
$stmt->bind_param('ss', $username, $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->close();
    die('이미 사용중인 아이디 또는 이메일입니다.');
}
$stmt->close();

$pw_hash = password_hash($password, PASSWORD_DEFAULT);
$upload_path_in_db = null;

if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $tmp = $_FILES['profile_image']['tmp_name'];
    $orig = $_FILES['profile_image']['name'];

    // 크기 제한 (2MB)
    if ($_FILES['profile_image']['size'] > 2*1024*1024) die('프로필 이미지는 2MB 이하만 허용됩니다.');

    if (!allowed_file($orig, $tmp, ['jpg','jpeg','png','gif'])) die('허용되지 않는 이미지 형식입니다.');

    $newname = safe_filename($username, $orig);
    $target_dir = __DIR__ . '/uploads';
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
    $target_path = $target_dir . '/' . $newname;

    if (!move_uploaded_file($tmp, $target_path)) {
        die('이미지 업로드 실패');
    }
    $upload_path_in_db = 'uploads/' . $newname;
}

$stmt = $conn->prepare("INSERT INTO members (username,email,password_hash,profile_image) VALUES (?,?,?,?)");
$stmt->bind_param('ssss', $username, $email, $pw_hash, $upload_path_in_db);
if ($stmt->execute()) {
    echo '회원가입 완료. <a href="login_form.php">로그인</a>';
} else {
    error_log('Register error: ' . $stmt->error);
    echo '등록 중 오류가 발생했습니다.';
}
$stmt->close();
$conn->close();