<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    exit('잘못된 접근');
}
if (!csrf_check($_POST['csrf_token'] ?? '')) {
    exit('CSRF 검증 실패');
}

$username = trim($_POST['username'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $email === '' || $password === '') {
    exit('모든 필드를 입력하세요.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit('유효한 이메일 형식이 아닙니다.');
}
if (strlen($password) < 6) {
    exit('비밀번호는 최소 6자 이상이어야 합니다.');
}

// 비밀번호 해시
$pw_hash = password_hash($password, PASSWORD_DEFAULT);

// 중복 확인
try {
    $check = $pdo->prepare("SELECT id FROM members WHERE username = :username OR email = :email LIMIT 1");
    $check->execute([
        ':username' => $username,
        ':email'    => $email,
    ]);

    if ($check->rowCount() > 0) {
        exit('이미 사용중인 아이디 또는 이메일입니다. <a href="register_form.php">돌아가기</a>');
    }
} catch (PDOException $e) {
    error_log("Register duplicate check error: " . $e->getMessage());
    exit('DB 오류 (중복 확인)');
}

// 프로필 이미지 처리
$upload_path_in_db = null;

if (!empty($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {
    $tmp  = $_FILES['profile_image']['tmp_name'];
    $orig = $_FILES['profile_image']['name'];

    if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
        exit('프로필 이미지는 2MB 이하만 가능합니다.');
    }

    if (!allowed_file($orig, $tmp, ['jpg','jpeg','png','gif'])) {
        exit('허용되지 않은 이미지 형식입니다.');
    }

    $newname = safe_filename($username, $orig);

    $target_dir = __DIR__ . '/uploads';
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0755, true);
    }

    $target_path = $target_dir . '/' . $newname;

    if (!move_uploaded_file($tmp, $target_path)) {
        exit('이미지 업로드 실패');
    }

    $upload_path_in_db = 'uploads/' . $newname;
}

// 회원 저장
try {
    $stmt = $pdo->prepare("
        INSERT INTO members (username, email, password_hash, profile_image)
        VALUES (:username, :email, :password_hash, :profile_image)
    ");
    $stmt->execute([
        ':username'      => $username,
        ':email'         => $email,
        ':password_hash' => $pw_hash,
        ':profile_image' => $upload_path_in_db,
    ]);

    echo '회원가입 완료되었습니다. <a href="login_form.php">로그인 하러가기</a>';

} catch (PDOException $e) {
    error_log("Register insert error: " . $e->getMessage());
    exit('등록 중 오류가 발생했습니다.');
}
