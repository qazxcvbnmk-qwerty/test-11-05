<?php
require_once "config.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit('잘못된 접근');
if (!csrf_check($_POST['csrf_token'] ?? '')) die('CSRF 검증 실패');

// 입력값 처리
$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $email === '' || $password === '') {
    die('모든 필드를 입력하세요.');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) die('유효한 이메일 형식이 아닙니다.');
if (strlen($password) < 6) die('비밀번호는 최소 6자 이상이어야 합니다.');

// 비밀번호 해시
$pw_hash = password_hash($password, PASSWORD_DEFAULT);

// -------------------------------
// 중복 확인
// -------------------------------
try {
    $check = $pdo->prepare("SELECT id FROM members WHERE username = :username OR email = :email LIMIT 1");
    $check->execute([
        ':username' => $username,
        ':email' => $email
    ]);

    if ($check->rowCount() > 0) {
        die('이미 사용중인 아이디 또는 이메일입니다.');
    }
} catch (PDOException $e) {
    die("DB 오류 (중복확인): " . $e->getMessage());
}

// -------------------------------
// 프로필 이미지 처리
// -------------------------------
$upload_path_in_db = null;

if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] === UPLOAD_ERR_OK) {

    $tmp = $_FILES['profile_image']['tmp_name'];
    $orig = $_FILES['profile_image']['name'];

    // 2MB 제한
    if ($_FILES['profile_image']['size'] > 2 * 1024 * 1024) {
        die('프로필 이미지는 2MB 이하만 가능합니다.');
    }

    if (!allowed_file($orig, $tmp, ['jpg','jpeg','png','gif'])) {
        die('허용되지 않은 이미지 형식입니다.');
    }

    // 안전한 파일명 생성
    $newname = safe_filename($username, $orig);

    $target_dir = __DIR__ . '/uploads';
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    $target_path = $target_dir . '/' . $newname;

    if (!move_uploaded_file($tmp, $target_path)) {
        die('이미지 업로드 실패');
    }

    $upload_path_in_db = 'uploads/' . $newname;
}

// -------------------------------
// 회원 저장
// -------------------------------
try {
    $stmt = $pdo->prepare("
        INSERT INTO members (username, email, password_hash, profile_image)
        VALUES (:username, :email, :password_hash, :profile_image)
    ");

    $stmt->execute([
        ':username' => $username,
        ':email' => $email,
        ':password_hash' => $pw_hash,
        ':profile_image' => $upload_path_in_db
    ]);

    echo '회원가입 완료. <a href="login_form.php">로그인</a>';

} catch (PDOException $e) {
    error_log("Register error: " . $e->getMessage());
    die('등록 중 오류가 발생했습니다.');
}
?>
