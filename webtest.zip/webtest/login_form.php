<?php require_once 'header.php'; ?>

<h1>로그인</h1>

<form action="login.php" method="POST" class="form">
    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">

    <label>아이디</label>
    <input class="input" type="text" name="username" required>

    <label>비밀번호</label>
    <input class="input" type="password" name="password" required>

    <button class="btn" type="submit">로그인</button>
</form>

<p><a href="register_form.php">아직 계정이 없으신가요? 회원가입</a></p>

<?php require_once 'footer.php'; ?>
