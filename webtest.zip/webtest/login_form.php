<?php require_once 'header.php'; ?>
<h1>로그인</h1>
<form action="login.php" method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">
    <label>아이디:</label><br>
    <input class="input" type="text" name="username" required><br>
    <label>비밀번호:</label><br>
    <input class="input" type="password" name="password" required><br><br>
    <button class="btn" type="submit">로그인</button>
</form>
<?php require_once 'footer.php'; ?>