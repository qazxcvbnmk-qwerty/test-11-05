<?php
require_once 'config.php';
require_login();

$filename = basename($_GET['file'] ?? '');
if ($filename === '') { http_response_code(400); die('파일명 누락'); }

// DB에서 현재 사용자 이미지 조회
$stmt = $conn->prepare('SELECT profile_image FROM members WHERE id=?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($stored_path);
$stmt->fetch();
$stmt->close();

if (!$stored_path) { http_response_code(404); die('이미지 없음'); }
if (basename($stored_path) !== $filename) { http_response_code(403); die('권한 없음'); }

$real = __DIR__ . '/' . $stored_path;
if (!file_exists($real)) { http_response_code(404); die('파일 없음'); }

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $real);
finfo_close($finfo);

// 간단한 허용 체크
if (strpos($mime, 'image/') !== 0) { http_response_code(403); die('이미지 아님'); }

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($real));
readfile($real);
exit;