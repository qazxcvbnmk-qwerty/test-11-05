<?php
require_once 'config.php';
require_login();

$filename = basename($_GET['file'] ?? '');
if ($filename === '') {
    http_response_code(400);
    exit('파일명 누락');
}

try {
    $stmt = $pdo->prepare("SELECT profile_image FROM members WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $row = $stmt->fetch();
} catch (PDOException $e) {
    error_log('serve_image DB error: ' . $e->getMessage());
    http_response_code(500);
    exit('DB 오류');
}

$stored_path = $row['profile_image'] ?? null;
if (!$stored_path) {
    http_response_code(404);
    exit('이미지 없음');
}

if (basename($stored_path) !== $filename) {
    http_response_code(403);
    exit('권한 없음');
}

$real = __DIR__ . '/' . $stored_path;
if (!file_exists($real)) {
    http_response_code(404);
    exit('파일 없음');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime  = finfo_file($finfo, $real);
finfo_close($finfo);

if (strpos($mime, 'image/') !== 0) {
    http_response_code(403);
    exit('이미지 아님');
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($real));
readfile($real);
exit;
