<?php
// footer.php
?>
</main>
<hr>
<footer class="site-footer">
  <span>© <?= date('Y') ?> My Secure Site</span>
</footer>
</div><!-- .container -->
</body>
</html>
