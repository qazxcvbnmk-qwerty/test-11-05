<hr>
<footer class="small">© Your Site</footer>

</div> <!-- container END -->
</body>
</html>
