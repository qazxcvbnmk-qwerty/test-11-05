<?php
require_once "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}

$uid = $_SESSION['user_id'];
$message = "";

// 업로드 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {

    $file = $_FILES['file'];
    $temp = $file['tmp_name'];
    $name = time() . "_" . basename($file['name']);
    $key = "uploads/$uid/$name";

    try {
        $s3->putObject([
            'Bucket' => $S3_BUCKET,
            'Key'    => $key,
            'SourceFile' => $temp,
            'ACL'    => 'private'
        ]);
        $message = "업로드 성공!";
    } catch (Exception $e) {
        $message = "업로드 실패: " . $e->getMessage();
    }
}

// 삭제 처리
if (isset($_GET['delete'])) {
    $key = $_GET['delete'];

    try {
        $s3->deleteObject([
            'Bucket' => $S3_BUCKET,
            'Key'    => $key
        ]);
        header("Location: files.php");
        exit;
    } catch (Exception $e) {
        $message = "삭제 실패: " . $e->getMessage();
    }
}

// 파일 목록 가져오기
$files = $s3->listObjectsV2([
    'Bucket' => $S3_BUCKET,
    'Prefix' => "uploads/$uid/"
]);
?>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>파일 공유</title>
</head>
<body>

<h1>📂 파일 공유</h1>

<p style="color:blue;"><?php echo $message; ?></p>

<!-- 파일 업로드 폼 -->
<form action="files.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
    <button type="submit">업로드</button>
</form>
<br>

<h2>내 파일 목록</h2>

<?php if (isset($files['Contents'])): ?>
<ul>
<?php foreach ($files['Contents'] as $file): ?>
    <?php $key = $file['Key']; ?>
    <?php if ($key === "uploads/$uid/") continue; ?>

    <li>
        <?php echo basename($key); ?>
        | <a href="s3download.php?file=<?php echo urlencode($key); ?>">다운로드</a>
        | <a href="files.php?delete=<?php echo urlencode($key); ?>" onclick="return confirm('삭제할까요?');">삭제</a>
    </li>
<?php endforeach; ?>
</ul>
<?php else: ?>
<p>업로드된 파일이 없습니다.</p>
<?php endif; ?>

<p><a href="dashboard.php">← 대시보드로</a></p>

</body>
</html>
