<?php
require_once 'config.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$message = '';

// 업로드 처리
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    if (!csrf_check($_POST['csrf_token'] ?? '')) die('CSRF 실패');

    $file = $_FILES['file'];
    if ($file['error'] !== UPLOAD_ERR_OK) { $message = '파일 업로드 오류'; }
    elseif ($file['size'] > 10*1024*1024) { $message = '10MB 이하만 업로드 가능'; }
    else {
        $orig = $file['name'];
        $tmp = $file['tmp_name'];
        if (!allowed_file($orig, $tmp, ['jpg','jpeg','png','gif','pdf','txt'])) {
            $message = '허용되지 않는 파일';
        } else {
            $name = safe_filename($_SESSION['username'], $orig);
            $key = "uploads/{$uid}/{$name}";
            try {
                $s3->putObject([
                    'Bucket' => $S3_BUCKET,
                    'Key'    => $key,
                    'SourceFile' => $tmp,
                    'ACL'    => 'private'
                ]);
                $message = '업로드 성공';
            } catch (Exception $e) {
                error_log('S3 upload error: ' . $e->getMessage());
                $message = '업로드 실패';
            }
        }
    }
}

// 삭제 처리
if (isset($_GET['delete'])) {
    $del = $_GET['delete'];
    // 안전 검증: 반드시 자신의 prefix여야 함
    if (strpos($del, "uploads/{$uid}/") !== 0) {
        $message = '권한 없음';
    } else {
        try {
            $s3->deleteObject(['Bucket' => $S3_BUCKET, 'Key' => $del]);
            header('Location: files.php'); exit;
        } catch (Exception $e) {
            error_log('S3 delete error: '.$e->getMessage());
            $message = '삭제 실패';
        }
    }
}

// 목록
try {
    $files = $s3->listObjectsV2(['Bucket' => $S3_BUCKET, 'Prefix' => "uploads/{$uid}/"]);
} catch (Exception $e) {
    $files = [];
}
require_once 'header.php';
?>

<h1>📂 파일 공유</h1>
<p class="small" style="color:blue"><?php echo e($message); ?></p>

<form action="files.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">
    <input type="file" name="file">
    <button class="btn" type="submit">업로드</button>
</form>

<h2>내 파일 목록</h2>
<?php if (!empty($files['Contents'])): ?>
<ul class="file-list">
<?php foreach ($files['Contents'] as $file):
    $key = $file['Key'];
    if ($key === "uploads/{$uid}/") continue;
    $base = basename($key);
?>
<li>
    <?php echo e($base); ?>
    | <a class="btn ghost" href="s3download.php?file=<?php echo urlencode($key); ?>">다운로드</a>
    | <a class="btn ghost" href="files.php?delete=<?php echo urlencode($key); ?>" onclick="return confirm('삭제할까요?');">삭제</a>
</li>
<?php endforeach; ?>
</ul>
<?php else: ?>
<p>업로드된 파일이 없습니다.</p>
<?php endif; ?>

<p><a href="dashboard.php">← 대시보드로</a></p>
<?php require_once 'footer.php'; ?>