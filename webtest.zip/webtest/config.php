<?php
// config.php
session_start();

// 개발 시 에러 표시 (운영에서는 0으로 바꾸세요)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ===============================
// 🔥 RDS 연결 설정
// ===============================
$DB_HOST = 'p1.c1yu08qygkd3.ap-northeast-2.rds.amazonaws.com';
$DB_USER = 'admin';
$DB_PASS = 'password';
$DB_NAME = 'p1db';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    error_log("DB connection failed: " . $e->getMessage());
    die("데이터베이스 연결 실패");
}

// ===============================
// 🔥 AWS S3 설정
// ===============================
require_once __DIR__ . '/vendor/autoload.php';

use Aws\S3\S3Client;

define('S3_REGION', 'ap-northeast-2');
define('S3_BUCKET', 'firpjttest9266');

$s3 = new S3Client([
    'version'     => 'latest',
    'region'      => S3_REGION,
    // EC2에 부여된 IAM Role(EC2-SSM-Role)을 통해 인증
    'credentials' => false,
]);

// ===============================
// 공통 함수 로드
// ===============================
require_once __DIR__ . '/functions.php';
