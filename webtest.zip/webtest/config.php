<?php
// config.php
session_start();

// 개발 시 에러 표시 / 운영 시 끄기
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ===============================
// 🔥 RDS 연결 설정 (수정됨)
// ===============================
$DB_HOST = 'p1-db.c1yu08qygkd3.ap-northeast-2.rds.amazonaws.com';
$DB_USER = 'admin';
$DB_PASS = 'password';
$DB_NAME = 'p1db';   // ⚠️ 이 DB 이름은 RDS 안에 만들어야 함 (예: CREATE DATABASE appdb)

// MySQLi 대신 PDO 사용 → 더 안전
try {
    $conn = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    error_log("DB connection failed: " . $e->getMessage());
    die("데이터베이스 연결 실패");
}

// ===============================
// 🔥 AWS S3 설정 (수정됨)
// ===============================
require_once __DIR__ . '/vendor/autoload.php';
use Aws\S3\S3Client;

$S3_REGION = 'ap-northeast-2';
$S3_BUCKET = 'firpjttest9266';   // ← 실제 버킷명으로 수정됨

$s3 = new S3Client([
    'version' => 'latest',
    'region'  => $S3_REGION,
    // IAM 역할로 자동 인증 (EC2에 역할 부여해야 함)
    'credentials' => false
]);

// ===============================
// 공통 함수 로드
// ===============================
require_once __DIR__ . '/functions.php';
