<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') exit('잘못된 접근');
if (!csrf_check($_POST['csrf_token'] ?? '')) die('CSRF 검증 실패');

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

if ($username === '' || $password === '') {
    die('아이디와 비밀번호를 입력하세요');
}

try {
    // 사용자 조회
    $stmt = $pdo->prepare("
        SELECT id, username, password_hash, profile_image 
        FROM members 
        WHERE username = :username
        LIMIT 1
    ");
    $stmt->execute([':username' => $username]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && password_verify($password, $row['password_hash'])) {
        session_regenerate_id(true);

        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['profile_image'] = $row['profile_image'];

        header('Location: dashboard.php');
        exit;
    }

    echo '아이디 또는 비밀번호가 잘못되었습니다.';

} catch (PDOException $e) {
    error_log("Login error: " . $e->getMessage());
    echo "로그인 오류가 발생했습니다.";
}

