<?php
require_once "config.php";

// 1. 폼 데이터 받기
$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

// 2. 유효성 확인
if ($username === '' || $password === '') {
    die("아이디와 비밀번호를 모두 입력하세요. <a href='login_form.php'>돌아가기</a>");
}

// 3. 사용자 조회
$stmt = $conn->prepare("SELECT id, username, password_hash, profile_image FROM members WHERE username = ? LIMIT 1");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    
    // 4. 비밀번호 검증
    if (password_verify($password, $row['password_hash'])) {
        // 5. 세션에 사용자 정보 저장
        session_regenerate_id(true); // 세션 고정 방지
        
        $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['profile_image'] = $row['profile_image'];
        
        // 6. 대시보드로 리디렉션
        header("Location: dashboard.php");
        exit;
    } else {
        echo "비밀번호가 틀렸습니다. <a href='login_form.php'>다시 시도</a>";
    }
} else {
    echo "존재하지 않는 아이디입니다. <a href='register_form.php'>회원가입</a>";
}

$stmt->close();
$conn->close();
?>