<?php require_once 'header.php'; ?>

<h1>Welcome</h1>
<p>이 사이트는 간단한 <strong>회원제 파일 공유 서비스</strong>입니다.</p>

<?php if (empty($_SESSION['user_id'])): ?>
  <p>
    <a class="btn" href="login_form.php">로그인</a>
    <a class="btn ghost" href="register_form.php">회원가입</a>
  </p>
<?php else: ?>
  <p>
    <a class="btn" href="dashboard.php">대시보드로 이동</a>
  </p>
<?php endif; ?>

<?php require_once 'footer.php'; ?>
