<?php
require_once "config.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: login_form.php");
    exit;
}
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>대시보드</title>
</head>
<body>
<h1><?php echo htmlspecialchars($username); ?> 님 환영합니다</h1>

<p><a href="files.php">📂 파일 공유 페이지로 이동</a></p>
<p><a href="logout.php">로그아웃</a></p>

</body>
</html>
