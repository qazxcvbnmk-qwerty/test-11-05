<?php
require_once 'config.php';
require_login();

$username = $_SESSION['username'] ?? '';
$profile  = $_SESSION['profile_image'] ?? null;
require_once 'header.php';
?>

<div class="dashboard-header">
  <div>
    <h1><?php echo e($username); ?> 님 환영합니다</h1>
    <p>대시보드에서 프로필과 파일을 관리할 수 있습니다.</p>
  </div>

  <div class="profile-box">
    <?php if ($profile): ?>
      <img src="serve_image.php?file=<?php echo urlencode(basename($profile)); ?>"
           alt="프로필 이미지"
           class="profile-img">
    <?php else: ?>
      <div class="profile-placeholder">프로필 없음</div>
    <?php endif; ?>
  </div>
</div>

<p>
  <a class="btn" href="files.php">📂 파일 공유 페이지로 이동</a>
</p>

<?php require_once 'footer.php'; ?>
