<?php
require_once 'config.php';
require_once 'header.php';

/* --- 세션 로그인 여부 확인 함수 없을 경우 대비 --- */
if (!function_exists('require_login')) {
    function require_login() {
        if (empty($_SESSION['user_id'])) {
            header("Location: login_form.php");
            exit;
        }
    }
}

/* --- XSS 방지용 escape 함수 없을 경우 대비 --- */
if (!function_exists('e')) {
    function e($str) {
        return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
    }
}

require_login();

$username = $_SESSION['username'];
$profile  = $_SESSION['profile_image'] ?? null;
?>

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
  <h1><?php echo e($username); ?> 님 환영합니다</h1>

  <div class="profile" style="text-align:right;">
    <?php if ($profile): ?>
      <img src="serve_image.php?file=<?php echo urlencode(basename($profile)); ?>" 
           alt="프로필" 
           style="width:70px;height:70px;border-radius:50%;object-fit:cover;">
    <?php else: ?>
      <div class="small" style="color:#888;">프로필 없음</div>
    <?php endif; ?>
  </div>
</div>

<p><a class="btn" href="files.php">📂 파일 공유 페이지로 이동</a></p>

<?php require_once 'footer.php'; ?>
