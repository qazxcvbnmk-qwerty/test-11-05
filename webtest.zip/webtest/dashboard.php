<?php
require_once 'header.php';
require_login();
$username = $_SESSION['username'];
$profile = $_SESSION['profile_image'] ?? null;
?>

<div style="display:flex;justify-content:space-between;align-items:center">
  <h1><?php echo e($username); ?> 님 환영합니다</h1>
  <div class="profile">
    <?php if ($profile): ?>
      <img src="serve_image.php?file=<?php echo urlencode(basename($profile)); ?>" alt="프로필">
    <?php else: ?>
      <div class="small">프로필 없음</div>
    <?php endif; ?>
  </div>
</div>

<p><a class="btn" href="files.php">📂 파일 공유 페이지로 이동</a></p>
<?php require_once 'footer.php'; ?>