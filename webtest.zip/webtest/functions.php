<?php
// functions.php

// 간단한 출력 이스케이프
function e($s) { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// CSRF 토큰
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_check($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token ?? '');
}

// 허용 확장자/마임 검사
function allowed_file($filename, $tmpfile, $allowed_ext = ['jpg','jpeg','png','gif','pdf','txt']) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext)) return false;

    // fileinfo로 실제 MIME 검사
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $tmpfile);
    finfo_close($finfo);

    $mime_map = [
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
        'gif' => ['image/gif'],
        'pdf' => ['application/pdf'],
        'txt' => ['text/plain','text/*']
    ];

    return in_array($mime, $mime_map[$ext] ?? []) || (strpos($mime, 'text/') === 0 && $ext === 'txt');
}

// 파일명 안전화
function safe_filename($username, $orig) {
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $name = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($orig, PATHINFO_FILENAME));
    return time() . "_" . preg_replace('/[^a-zA-Z0-9_-]/', '_', $username) . "_" . $name . "." . $ext;
}

// 로그인 체크
function require_login() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login_form.php');
        exit;
    }
}