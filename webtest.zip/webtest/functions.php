<?php
// functions.php

// 간단한 출력 이스케이프
function e($s) {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// CSRF 토큰 생성
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF 토큰 검증
function csrf_check($token) {
    return hash_equals($_SESSION['csrf_token'] ?? '', $token ?? '');
}

// 허용 확장자/마임 검사
function allowed_file($filename, $tmpfile, $allowed_ext = ['jpg','jpeg','png','gif','pdf','txt']) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed_ext)) return false;

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if (!$finfo) return false;

    $mime = finfo_file($finfo, $tmpfile);
    finfo_close($finfo);

    $mime_map = [
        'jpg'  => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png'  => ['image/png'],
        'gif'  => ['image/gif'],
        'pdf'  => ['application/pdf'],
        'txt'  => ['text/plain'],
    ];

    // txt는 text/* 모두 허용
    if ($ext === 'txt' && strpos($mime, 'text/') === 0) {
        return true;
    }

    return in_array($mime, $mime_map[$ext] ?? []);
}

// 파일명 안전화
function safe_filename($username, $orig) {
    $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $name = pathinfo($orig, PATHINFO_FILENAME);

    $name = preg_replace('/[^a-zA-Z0-9_-]/', '_', $name);
    $user = preg_replace('/[^a-zA-Z0-9_-]/', '_', $username);

    return time() . '_' . $user . '_' . $name . '.' . $ext;
}

// 로그인 체크
function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: login_form.php');
        exit;
    }
}
