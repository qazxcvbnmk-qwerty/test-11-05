<?php
// index.php
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome to My Homepage</h1>
    <p><a href="login_form.php">로그인</a></p>
</body>
</html>
