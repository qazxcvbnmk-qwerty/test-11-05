#!/bin/bash

# =================================================================
# Project Name: Project Janus (phjtest337)
# Description: Ransomware Detection & Failover Agent Setup
# =================================================================

# 1. 패키지 설치 대기 및 업데이트
echo "[1/6] 업데이트 및 필수 패키지 설치 중..."
until sudo apt update; do echo "패키지 매니저 대기 중..."; sleep 2; done
sudo apt install inotify-tools wget -y

# 2. CloudWatch Agent 설치
echo "[2/6] CloudWatch 에이전트 설치 중..."
CW_AGENT_DEB="amazon-cloudwatch-agent.deb"
wget https://s3.amazonaws.com/amazoncloudwatch-agent/ubuntu/amd64/latest/amazon-cloudwatch-agent.deb -O /tmp/$CW_AGENT_DEB
sudo dpkg -i /tmp/$CW_AGENT_DEB

# 3. CloudWatch Agent 설정 파일 생성
echo "[3/6] 에이전트 구성 파일 생성 중..."
sudo mkdir -p /opt/aws/amazon-cloudwatch-agent/bin/
cat <<EOF | sudo tee /opt/aws/amazon-cloudwatch-agent/bin/config.json
{
  "agent": { "run_as_user": "root" },
  "logs": {
    "logs_collected": {
      "files": {
        "collect_list": [
          {
            "file_path": "/var/log/janus_monitor.log",
            "log_group_name": "Ransomware-Detection-Log-Group",
            "log_stream_name": "{instance_id}",
            "retention_in_days": 7
          }
        ]
      }
    }
  }
}
EOF

# 4. 로그 파일 및 미끼 경로 초기화
echo "[4/6] 로그 및 미끼 경로 초기화 중..."
sudo touch /var/log/janus_monitor.log
sudo chmod 666 /var/log/janus_monitor.log
sudo mkdir -p /var/www/html

# 5. 실시간 감시 스크립트 생성 (monitor.sh)
echo "[5/6] 감시 스크립트 작성 중..."
cat <<'INNER_EOF' | sudo tee /usr/local/bin/monitor.sh
#!/bin/bash
# 미끼 파일 생성
HONEYPOT="/var/www/html/000_IMPORTANT_SYSTEM_DATA.docx"
echo "CRITICAL: Backup. DO NOT REMOVE." > $HONEYPOT
chown root:root $HONEYPOT
chmod 600 $HONEYPOT

# 실시간 이벤트 감시
inotifywait -m -e modify,delete,attrib,move $HONEYPOT | while read path action file
do
    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
    LOG_MSG="[RANSOMWARE_DETECTED] Action: $action | File: $file | Time: $TIMESTAMP"
    
    # 시스템 로그와 전용 로그 파일에 동시 기록
    logger "$LOG_MSG"
    echo "$LOG_MSG" >> /var/log/janus_monitor.log
done
INNER_EOF

sudo chmod +x /usr/local/bin/monitor.sh

# 6. 서비스 시작
echo "[6/6] 보안 서비스 가동 시작..."
# CloudWatch Agent 실행
sudo /opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/bin/config.json -s

# 기존 감시 프로세스 종료 후 재시작 (중복 방지)
sudo pkill -f monitor.sh || true
sudo nohup /usr/local/bin/monitor.sh > /var/log/janus_setup.log 2>&1 &

echo "✅ Project Janus 보안 에이전트 설치 완료!"
