<?php
$DB_HOST = "db.c1yu08qygkd3.ap-northeast-2.rds.amazonaws.com";
$DB_NAME = "Firpjt";
$DB_USER = "admin";
$DB_PASS = "password";

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die("DB Connection failed: " . $e->getMessage());
}
?>
