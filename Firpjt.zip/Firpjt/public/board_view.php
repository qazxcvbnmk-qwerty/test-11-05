<?php
require_once '../src/BoardService.php';
$service = new BoardService();
$post = $service->getPost($_GET['id']);
?>
<h2><?php echo htmlspecialchars($post['title']); ?></h2>
<p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
<a href="board.php">목록</a>
