<?php
require_once '../src/S3Service.php';
$awsKey = getenv('AWS_KEY');
$awsSecret = getenv('AWS_SECRET');
$s3 = new S3Service($awsKey, $awsSecret);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $filename = $_FILES['file']['name'];
    $url = $s3->getPresignedUrl($filename);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_PUT, true);
    curl_setopt($ch, CURLOPT_INFILE, fopen($_FILES['file']['tmp_name'], 'rb'));
    curl_setopt($ch, CURLOPT_INFILESIZE, $_FILES['file']['size']);
    curl_exec($ch);
    curl_close($ch);
    echo "업로드 완료: $filename";
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <button type="submit">S3 업로드</button>
</form>
