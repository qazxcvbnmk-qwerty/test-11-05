<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>firstpjtcompany</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/custom.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">firstpjtcompany</a>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav ml-auto">
      <?php if(isset($_SESSION['user'])): ?>
          <li class="nav-item"><a class="nav-link" href="logout.php">로그아웃</a></li>
      <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php">로그인</a></li>
          <li class="nav-item"><a class="nav-link" href="register.php">회원가입</a></li>
      <?php endif; ?>
    </ul>
  </div>
</nav>

<div class="container mt-5">
    <h1>Welcome to firstpjtcompany</h1>
    <p>게시판, 피드백, 투표, 전자서명, 파일 공유까지 한 곳에서!</p>
    <div class="list-group">
        <a href="board.php" class="list-group-item list-group-item-action">게시판</a>
        <a href="feedback.php" class="list-group-item list-group-item-action">익명 피드백</a>
        <a href="vote.php" class="list-group-item list-group-item-action">투표 게시판</a>
        <a href="sign_upload.php" class="list-group-item list-group-item-action">전자서명 게시판</a>
        <a href="s3_list.php" class="list-group-item list-group-item-action">파일 공유 게시판</a>
        <a href="admin.php" class="list-group-item list-group-item-action">관리자</a>
    </div>
</div>
</body>
</html>
