<?php
require_once '../src/S3Service.php';

$awsKey = getenv('AWS_KEY');
$awsSecret = getenv('AWS_SECRET');

$s3 = new S3Service($awsKey, $awsSecret);
$files = $s3->listFiles();
?>

<h2>S3 파일 목록 (firpjttest9266)</h2>
<ul>
<?php foreach($files as $file): ?>
    <li><a href="https://firpjttest9266.s3.ap-northeast-2.amazonaws.com/<?php echo urlencode($file); ?>" target="_blank">
        <?php echo htmlspecialchars($file); ?>
    </a></li>
<?php endforeach; ?>
</ul>
