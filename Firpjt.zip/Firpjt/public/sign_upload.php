<?php
require_once '../src/SignService.php';
session_start();
$service = new SignService();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $uploadDir = __DIR__ . '/../uploads/';
    $filename = basename($_FILES['file']['name']);
    move_uploaded_file($_FILES['file']['tmp_name'], $uploadDir . $filename);
    $service->uploadDocument($filename, $_SESSION['user'] ?? 'Anonymous');
    header("Location: sign_upload.php");
    exit;
}

$docs = $service->getAllDocuments();
?>

<h2>전자 서명 문서 업로드</h2>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <button type="submit">업로드</button>
</form>

<h3>업로드 문서 목록</h3>
<ul>
<?php foreach($docs as $doc): ?>
    <li><?php echo htmlspecialchars($doc['filename']); ?> (<?php echo $doc['user']; ?>)</li>
<?php endforeach; ?>
</ul>
