<?php
require_once '../src/BoardService.php';
session_start();
$service = new BoardService();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service->createPost($_POST['title'], $_POST['content'], $_SESSION['user']);
    header("Location: board.php");
    exit;
}
?>
<form method="POST">
    <input type="text" name="title" placeholder="제목" required>
    <textarea name="content" placeholder="내용" required></textarea>
    <button type="submit">작성</button>
</form>
