<?php
require_once '../src/VoteService.php';
$voteService = new VoteService();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['option'])) {
    $voteService->vote($_POST['option']);
    header("Location: vote.php");
    exit;
}

$options = $voteService->getResults();
?>

<h2>투표 게시판</h2>
<form method="POST">
<?php foreach($options as $opt): ?>
    <input type="radio" name="option" value="<?php echo $opt['id']; ?>" required> <?php echo htmlspecialchars($opt['option_name']); ?><br>
<?php endforeach; ?>
<button type="submit">투표하기</button>
</form>
