<?php
require_once '../src/BoardService.php';
session_start();
$service = new BoardService();
$posts = $service->getAllPosts();
?>
<h2>게시판</h2>
<a href="board_write.php">글쓰기</a>
<ul>
<?php foreach($posts as $post): ?>
    <li><a href="board_view.php?id=<?php echo $post['id']; ?>"><?php echo htmlspecialchars($post['title']); ?></a></li>
<?php endforeach; ?>
</ul>
