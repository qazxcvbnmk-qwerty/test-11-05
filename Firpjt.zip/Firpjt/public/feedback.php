<?php
require_once '../src/FeedbackService.php';
$service = new FeedbackService();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['message'])) {
    $service->submitFeedback($_POST['message']);
    header("Location: feedback.php");
    exit;
}

$feedbacks = $service->getAllFeedback();
?>

<h2>익명 피드백</h2>
<form method="POST">
    <textarea name="message" required></textarea>
    <button type="submit">제출</button>
</form>

<h3>피드백 목록</h3>
<ul>
<?php foreach($feedbacks as $fb): ?>
    <li><?php echo htmlspecialchars($fb['message']); ?> (<?php echo $fb['created_at']; ?>)</li>
<?php endforeach; ?>
</ul>
