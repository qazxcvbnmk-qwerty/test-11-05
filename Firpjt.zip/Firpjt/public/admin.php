<?php
require_once '../src/AdminService.php';
session_start();

if($_SESSION['role'] !== 'admin'){
    die("관리자만 접근 가능합니다.");
}

$adminService = new AdminService();

if(isset($_GET['delete'])){
    $adminService->deleteUser($_GET['delete']);
    header("Location: admin.php");
    exit;
}

$users = $adminService->getUsers();
?>

<h2>관리자 페이지</h2>
<table border="1">
<tr><th>ID</th><th>Username</th><th>Role</th><th>Action</th></tr>
<?php foreach($users as $user): ?>
<tr>
    <td><?php echo $user['id']; ?></td>
    <td><?php echo htmlspecialchars($user['username']); ?></td>
    <td><?php echo $user['role']; ?></td>
    <td><a href="admin.php?delete=<?php echo $user['id']; ?>" onclick="return confirm('삭제하시겠습니까?')">삭제</a></td>
</tr>
<?php endforeach; ?>
</table>
