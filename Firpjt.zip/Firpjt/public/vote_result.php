<?php
require_once '../src/VoteService.php';
$voteService = new VoteService();
$results = $voteService->getResults();
?>
<h2>투표 결과</h2>
<ul>
<?php foreach($results as $r): ?>
    <li><?php echo htmlspecialchars($r['option_name']); ?> : <?php echo $r['votes']; ?>표</li>
<?php endforeach; ?>
