<?php
require 'vendor/autoload.php';
use Aws\S3\S3Client;

class S3Service {
    private $s3;
    private $bucket;

    public function __construct($key, $secret, $region='ap-northeast-2') {
        $this->bucket = 'firpjttest9266'; // 버킷명 고정
        $this->s3 = new S3Client([
            'version' => 'latest',
            'region' => $region,
            'credentials' => [
                'key' => $key,
                'secret' => $secret
            ]
        ]);
    }

    /**
     * presigned URL 생성 (파일 업로드용)
     * @param string $filename S3에 저장될 파일명
     * @param string $expires URL 만료시간 (ex. '+1 hour')
     * @return string presigned URL
     */
    public function getPresignedUrl($filename, $expires='+1 hour') {
        $cmd = $this->s3->getCommand('PutObject', [
            'Bucket' => $this->bucket,
            'Key' => $filename
        ]);
        $request = $this->s3->createPresignedRequest($cmd, $expires);
        return (string)$request->getUri();
    }

    /**
     * 버킷 파일 리스트 가져오기
     */
    public function listFiles() {
        $result = $this->s3->listObjectsV2([
            'Bucket' => $this->bucket
        ]);
        $files = [];
        if (isset($result['Contents'])) {
            foreach ($result['Contents'] as $object) {
                $files[] = $object['Key'];
            }
        }
        return $files;
    }
}
?>

