<?php
require_once __DIR__ . '/../config/db.php';

class SignService {
    public function uploadDocument($filename, $user) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO signed_docs (filename, user, created_at) VALUES (?, ?, NOW())");
        return $stmt->execute([$filename, $user]);
    }

    public function getAllDocuments() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM signed_docs ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
