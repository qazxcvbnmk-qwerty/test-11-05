<?php
require_once __DIR__ . '/../config/db.php';

class FeedbackService {
    public function submitFeedback($message) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO feedback (message, created_at) VALUES (?, NOW())");
        return $stmt->execute([$message]);
    }

    public function getAllFeedback() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM feedback ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
