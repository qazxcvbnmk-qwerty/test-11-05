<?php
require_once __DIR__ . '/../config/db.php';

class AdminService {
    public function getUsers() {
        global $pdo;
        $stmt = $pdo->query("SELECT id, username, role FROM users");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function deleteUser($user_id) {
        global $pdo;
        $stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
        return $stmt->execute([$user_id]);
    }
}
?>
