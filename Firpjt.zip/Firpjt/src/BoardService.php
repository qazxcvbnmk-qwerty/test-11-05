<?php
require_once '../config/db.php';

class BoardService {
    public function getAllPosts() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM board ORDER BY created_at DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getPost($id) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT * FROM board WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function createPost($title, $content, $author) {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO board (title, content, author, created_at) VALUES (?, ?, ?, NOW())");
        return $stmt->execute([$title, $content, $author]);
    }
}
