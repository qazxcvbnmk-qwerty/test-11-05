<?php
require_once __DIR__ . '/../config/db.php';

class VoteService {
    public function vote($option_id) {
        global $pdo;
        $stmt = $pdo->prepare("UPDATE vote_options SET votes = votes + 1 WHERE id=?");
        return $stmt->execute([$option_id]);
    }

    public function getResults() {
        global $pdo;
        $stmt = $pdo->query("SELECT * FROM vote_options");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
