# firstpjtcompany

PHP 기반 통합 웹 애플리케이션

## 기능

- 회원가입, 로그인/로그아웃
- 게시판 (글 작성, 조회, 목록)
- 익명 피드백
- 투표 게시판
- S3 파일 업로드
- 관리자 페이지

## 설치

1. PHP 8 이상, Composer, MySQL 설치
2. 레포지토리 클론

```bash
git clone <레포지토리_URL>
cd firstpjtcompany
composer install
