document.querySelector('input[type="file"]').addEventListener('change', function() {
    console.log('파일 선택됨:', this.files[0].name);
});
